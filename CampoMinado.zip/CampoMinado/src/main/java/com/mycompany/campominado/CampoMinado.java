/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.campominado;

/**
 *
 * @author JhéssikLeal
 */
public class CampoMinado {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
